import abacaxi, { myMod1_nomeada, PI, obj, nome, idade } from './modules/mod1.js'

const myMod = abacaxi()
console.log("app rodando", myMod1_nomeada())
console.log(obj.foo, obj.bar, nome, idade)