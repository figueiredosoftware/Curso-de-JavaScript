export function MyMod2() {
    this.name = "My Mod 2"
}