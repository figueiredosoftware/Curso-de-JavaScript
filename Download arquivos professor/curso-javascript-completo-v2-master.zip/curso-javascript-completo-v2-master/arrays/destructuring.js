const arr = [10, 20, 30]

const [n1, , n2] = arr
console.log(n1)
console.log(n2)