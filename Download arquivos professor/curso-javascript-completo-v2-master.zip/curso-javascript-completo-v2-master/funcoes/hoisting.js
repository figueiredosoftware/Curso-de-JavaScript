
teste()

function teste() {
    console.log("teste")
}


