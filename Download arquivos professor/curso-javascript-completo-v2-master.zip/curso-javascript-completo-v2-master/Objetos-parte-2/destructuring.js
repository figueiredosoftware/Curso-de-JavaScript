const eu = { nome: "daniel", sobrenome: "tapias morales" }

let { nome: n, sobrenome } = eu
console.log(n)
console.log(sobrenome)