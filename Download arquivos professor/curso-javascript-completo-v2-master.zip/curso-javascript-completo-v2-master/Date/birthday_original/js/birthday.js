function quantoFaltaPara(m, d) {


}
