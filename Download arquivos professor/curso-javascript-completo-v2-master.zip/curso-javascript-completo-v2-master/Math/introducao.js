console.log(Math.min(1, 2, 3, 4, 5))
console.log(Math.max(1, 2, 10, 4, 5))
let arr = [1, 2, 10, 4, 5]
console.log(Math.max(...arr))

console.log(Math.round(45.50000001))

console.log(Math.floor(49.9999999))
console.log(Math.ceil(49.00000001))

console.log(Math.pow(2, 3))
console.log(2 ** 3)

console.log(Math.sqrt(49))
console.log(Math.cbrt(8))

console.log(Math.floor(Math.random() * 10))

