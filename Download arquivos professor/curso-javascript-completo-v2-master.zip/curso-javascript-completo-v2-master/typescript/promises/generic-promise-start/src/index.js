"use strict";
console.log("rodando");
