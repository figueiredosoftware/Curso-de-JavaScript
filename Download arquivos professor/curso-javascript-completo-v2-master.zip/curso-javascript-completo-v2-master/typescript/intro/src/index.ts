const msg = "string 3"

console.log(msg)
