const msg = "string 3"

export default msg