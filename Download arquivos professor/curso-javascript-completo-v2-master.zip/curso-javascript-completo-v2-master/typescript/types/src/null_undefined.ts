const isNull: null = null
const isUndefined: undefined = undefined
