// enum Sizes {
//     SMALL, NORMAL, LARGE
// }

enum Sizes {
    SMALL = "12px",
    NORMAL = "16px",
    LARGE = "24px"
}

console.log(Sizes.SMALL) // "12px"