let msg: string = "123"
console.log(msg)

let n: number = 123

let isValid: boolean = false