let aluno2: { nome: string, aprovado?: boolean, idade: number, notas: [number, number, number, number] }


aluno2 = {
    notas: [1, 2, 3, 4],
    nome: "daniel",
    idade: 28
}