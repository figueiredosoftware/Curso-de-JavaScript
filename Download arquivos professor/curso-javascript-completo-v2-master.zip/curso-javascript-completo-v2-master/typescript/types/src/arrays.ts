let arrayDeNumeros: number[]

arrayDeNumeros = [1, 2, 3]

let arrayDeStrings: string[]
arrayDeStrings = ["a", "b", "11233"]

let arrayDeStringsGeneric: Array<string>
arrayDeStringsGeneric = ["teste", "teste2", "teste 3"]