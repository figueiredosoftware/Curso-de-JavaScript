class MateriasService {
    constructor() {
        this.materias = ["portugues", "matematica", "historia", "ciencias"]
    }
}