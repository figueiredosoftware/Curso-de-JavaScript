import { teste } from './modules/mod_esm.mjs'
import { teste as teste2 } from './modules/mod_esm2.mjs'

console.log(teste)
console.log(teste2)
