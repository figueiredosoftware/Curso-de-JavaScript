const mod1 = "mod1"
const abacaxi = "abacaxi"

module.exports.teste = [1, 2, 3]