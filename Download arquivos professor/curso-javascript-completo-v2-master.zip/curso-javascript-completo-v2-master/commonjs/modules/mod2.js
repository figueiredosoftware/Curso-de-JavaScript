module.exports.teste = "uma string exportada"

