// module.exports.teste = "ola mundo"
exports.fn = () => {
    console.log("funcao em module.exports")
    return " -- funcao em module.exports --"
}



// module.exports é o {} exportado