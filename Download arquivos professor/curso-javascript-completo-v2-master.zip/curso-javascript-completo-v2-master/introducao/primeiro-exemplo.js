console.log("Javascript funcionando 2222");


/*
let nome = "Daniel"
console.log(10 + 20)
*/

console.log("qualquer coisas")

// uma unica linha

let nome = "Daniel"; alert(nome)

const hasAttrubite = ""





