export const userId = 2

const PATH = "http://localhost:3000"
const urlUsers = `${PATH}/users`
const urlTasks = `${PATH}/tasks`

export { urlTasks, urlUsers }


