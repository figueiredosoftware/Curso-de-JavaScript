let n = 1

n = n || 10

console.log(n)

let isValid = 0

// if (isValid) {
//     console.log("é valido")
// }

isValid && console.log("é valido")
isValid || console.log("não é valido")
