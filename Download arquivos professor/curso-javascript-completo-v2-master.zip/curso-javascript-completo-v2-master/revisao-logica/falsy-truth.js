//falsy values - 0, "", NaN, undedfined, null, false
// truthy - todos os demais

let n

if (n) {
    console.log("true")
} else {
    console.log("false")
}