const http = require("http")
const fs = require("fs")

const getStaticFile = (url, type) => {

}