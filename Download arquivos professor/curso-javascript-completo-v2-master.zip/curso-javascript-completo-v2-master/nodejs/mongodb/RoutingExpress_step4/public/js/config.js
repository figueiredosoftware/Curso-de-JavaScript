export const userId = 2

const urlTasks = `/tasks`

export { urlTasks }


