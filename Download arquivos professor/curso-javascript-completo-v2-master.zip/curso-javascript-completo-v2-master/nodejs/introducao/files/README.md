# curso javascript completo

apenas um readme de teste [curso javascript completo](http://serfrontend.com/cursos/)
