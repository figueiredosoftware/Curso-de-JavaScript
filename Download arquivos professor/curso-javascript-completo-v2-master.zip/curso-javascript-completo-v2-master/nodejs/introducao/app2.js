const { getCount, increment } = require("./myCount")

increment()
increment()
increment()
increment()
increment()
increment()
increment()

console.log(getCount())